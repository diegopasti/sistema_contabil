# TinyToggle Change Log


## 1.2.0 
 * Add groups management
 * Add color css transition for switch status
 * Add method 'event' to set specific callbacks handler
 * Add optionals labels to controller 
 * Add external iconset library integration (Ex. Font Awesome)
 * Add AngularJs Directive


## 1.0.0

 * First Release
